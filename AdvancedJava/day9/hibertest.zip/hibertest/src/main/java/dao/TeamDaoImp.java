package dao;
import static utils.HibernateUtils.getFactory;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Team;

public class TeamDaoImp implements TeamDao {

	@Override
	public void addNewTeam(Team team) {

			Session session=getFactory().getCurrentSession();
			Transaction tx=session.beginTransaction();
			try{
				session.save(team);
				tx.commit();
			}
			catch(RuntimeException e) {
				if(tx!=null) {
					tx.rollback();
				}
				throw e;
			}
			finally {
				if(session!=null) {
					session.close();
				}
			}
		
	}

	@Override
	public Team displayTeamByAbbr(String abb) {
		Session session=getFactory().getCurrentSession();
		Transaction tx=session.beginTransaction();
		Team team=null;
		String jpql="select t from Team t where t.abbrevation is :abr";
		//String jpql = "Select e from Team e where abbrevation=:abbr";
				
		try{
			team=session.createQuery(jpql, Team.class)
					.setParameter("abr", abb)
					.getSingleResult();
			
			tx.commit();
		}
		catch(RuntimeException e) {
			if(tx!=null) {
				tx.rollback();
			}
			throw e;
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return team;
	}

	@Override
	public List<Team> displayTeamByMaxAge(int age) {
		Session session=getFactory().getCurrentSession();
		Transaction tx=session.beginTransaction();
		List<Team> list=null;
		String jpql="select t from Team t where t.maxAge > :age";
		
				
		try{
			list=session.createQuery(jpql, Team.class)
					.setParameter("age", age)
					.getResultList();
			
			tx.commit();
		}
		catch(RuntimeException e) {
			if(tx!=null) {
				tx.rollback();
			}
			throw e;
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return list;
	}

	@Override
	public void updateWicketsNAverage(String abbrevation, int battingAverage, int wicketsTaken) {
		Session session = getFactory().getCurrentSession();
	    Transaction tx = session.beginTransaction();
	    
	    String jpql = "UPDATE Team t SET t.wickets_taken = :wickets, t.batting_avg = :avg WHERE t.abbrevation = :abbr";
	    
	    try {
	        session.createQuery(jpql)
	                .setParameter("wickets", wicketsTaken)
	                .setParameter("avg", battingAverage)
	                .setParameter("abbr", abbrevation)
	                .executeUpdate();
	        
	        tx.commit();
	    } catch (RuntimeException e) {
	        if (tx != null) {
	            tx.rollback();
	        }
	        throw e;
	    } finally {
	        if (session != null) {
	            session.close();
	        }
	    }
		
	}
	
	

}
