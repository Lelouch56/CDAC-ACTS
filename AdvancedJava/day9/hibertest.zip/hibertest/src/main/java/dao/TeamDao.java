package dao;

import java.util.List;

import pojos.Team;

public interface TeamDao {
	
	public void addNewTeam(Team team);
	public Team displayTeamByAbbr(String abb);
	public List<Team> displayTeamByMaxAge(int age);
	public void updateWicketsNAverage(String abbrevation, int battingAverage, int wicketsTaken);
}
