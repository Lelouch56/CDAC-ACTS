package tester;

import java.util.Scanner;
import dao.TeamDaoImp;
import pojos.Team;

public class teamTester {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in);){
			TeamDaoImp teamDao=new TeamDaoImp();
			Team temp=null;
			
			boolean flag=true;
			while(flag) {
			System.out.println("Enter \n1.To add team \n2.To display team by abbrevation\n3.To display team by age");
			try {
			switch(sc.nextInt()) 
			{
			case 1:
				System.out.println("Enter  name,  abbrevation,  owner, maxAge,  batting_avg, wickets_taken");
				Team team=new Team(sc.next(),sc.next(), sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());
				teamDao.addNewTeam(team);
				break;
			case 2:
				System.out.println("Enter abbrevation");
				temp=teamDao.displayTeamByAbbr(sc.next());
				System.out.println(temp);
				break;
			case 3:
				System.out.println("Enter age");
				teamDao.displayTeamByMaxAge(sc.nextInt()).forEach(i->System.out.println(i));
				break;
			case 4:
				System.out.println("Enter team, new average, new wickets");
				teamDao.updateWicketsNAverage(sc.next(),sc.nextInt(),sc.nextInt());
				break;
			default:
				System.out.println("Invalid option");
				flag=false;
			}
			}
			catch(Exception e) {
				System.out.println(e);
			}
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}

}
