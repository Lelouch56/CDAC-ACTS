package pojos;
import javax.persistence.*;


@Entity
@Table(name="team_tb")
public class Team {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="team_id")
	private int id;
	private String name;
	private String abbrevation;
	private String owner;
	private int maxAge;
	private int batting_avg;
	private int wickets_taken;
	public Team(String name, String abbrevation, String owner, int maxAge, int batting_avg, int wickets_taken) {
		super();
		this.name = name;
		this.abbrevation = abbrevation;
		this.owner = owner;
		this.maxAge = maxAge;
		this.batting_avg = batting_avg;
		this.wickets_taken = wickets_taken;
	}
	  
    public Team() {
        // default constructor
    }
    
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + ", abbrevation=" + abbrevation + ", owner=" + owner + ", maxAge="
				+ maxAge + ", batting_avg=" + batting_avg + ", wickets_taken=" + wickets_taken + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAbbrevation() {
		return abbrevation;
	}
	public void setAbbrevation(String abbrevation) {
		this.abbrevation = abbrevation;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public int getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	public int getBatting_avg() {
		return batting_avg;
	}
	public void setBatting_avg(int batting_avg) {
		this.batting_avg = batting_avg;
	}
	public int getWickets_taken() {
		return wickets_taken;
	}
	public void setWickets_taken(int wickets_taken) {
		this.wickets_taken = wickets_taken;
	}
	
	
	
	
	
}
