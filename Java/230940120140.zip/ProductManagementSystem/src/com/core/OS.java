package com.core;

public enum OS {
	 ANDROID, WINDOWS, A
}
