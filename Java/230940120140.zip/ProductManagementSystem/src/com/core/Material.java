package com.core;

public enum Material {
    PLASTIC, METAL
}
